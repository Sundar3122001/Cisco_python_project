import os
import platform
import subprocess
import json

# Determine the current OS
current_os = platform.system().lower()
print("current_os", current_os)

def netinfo():
    # Read the existing configuration file
    with open('ifcfg.conf', 'r') as data:
        dic = {}
        for i in data:
            sp_data = i.strip().split('=')
            if len(sp_data) == 2:
                key, value = sp_data
                dic[key] = value
    
    # Modify specific parameters
    if 'onboot' in dic:
        dic['onboot'] = 'yes'
    if 'bootproto' in dic:
        dic['bootproto'] = 'static'
    if 'defroute' in dic:
        dic['defroute'] = 'no'

    dic['IPADDR'] = '192.168.1.200'
    dic['PREFIX'] = '255.255.255.0'

    print(dic)
    
    # Create a new config file and write the modified configuration
    with open('new_ifcfg.conf', 'w') as f:
        for key, value in dic.items():
            f.write(f"{key}={value}\n")

    # Create a new JSON file and write the new config data
    with open('net_ifcfg.json', 'w') as json_f:
        json.dump(dic, json_f, indent=4)

    # Create a dictionary to store network command outputs
    network_info = {}

    try:
        if current_os == 'darwin':
            commands = [
                'ifconfig',  
                'netstat',
                'networksetup -listallnetworkservices'
            ]
            for cmd in commands:
                result = subprocess.check_output(cmd, shell=True, text=True)
                print("result",result)
                
                network_info[cmd] = result.strip()
                print("network_info[cmd]",network_info[cmd])
    except Exception as e:
        print(f"An error occurred: {e}")

    print("Network Info:", network_info)

# function call
netinfo()
