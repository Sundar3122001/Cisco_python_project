import paramiko
import time

# Read hostnames from the file and establish SSH connections
with open('hostname_data.txt', 'r') as fobj:
    for var in fobj:
        var = var.strip()
        
        obj = paramiko.SSHClient()
        obj.load_system_host_keys()
        obj.set_missing_host_key_policy(paramiko.AutoAddPolicy())  
        try:
            obj.connect(var)

            stdin, stdout, stderr = obj.exec_command('ls -l')  
            output = stdout.read().decode('utf-8')  
            print("stdout:", output)
            
            with open('hostname.log', 'a') as hname:
                hname.write(f"Output from {var}:\n")
                hname.write(output + "\n")  
                hname.write("-" * 80 + "\n")  

        except Exception as e:
            print(f"Error connecting to {var}: {e}")
        finally:
            obj.close()
